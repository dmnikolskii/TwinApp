import React from 'react'

function DataPanel() {
    return (
        <div>
            <div className="reg_panel panel24 reg_label data_padding"></div>
        </div>
    )
}

export default DataPanel
